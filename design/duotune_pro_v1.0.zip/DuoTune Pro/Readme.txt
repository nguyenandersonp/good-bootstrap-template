DuoTune Pro - Set of 285 high quality duo tone icons

- For any theme related questions please contact our [Theme Support](//keenthemes.com/support/)

- Check out our market for more amazing products: [Keenthemes Market]//keenthemes.com/

- To learn more about the product license check out LICENSE file or [Product Licenses](//keenthemes.com/licensing)

- Stay tuned for updates via 
[Twitter](//www.twitter.com/keenthemes) 
[Instagram](//www.instagram.com/keenthemes) 
[Dribbble](//dribbble.com/keenthemes) 
[Facebook](//facebook.com/keenthemes) 


Happy using DuoTune Pro!